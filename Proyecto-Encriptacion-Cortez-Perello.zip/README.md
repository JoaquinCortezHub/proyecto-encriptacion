# proyecto-encriptacion

### Integrantes

- Perello Facundo
- Cortez Joaquín

## Consignas Generales

- Matriz de 4x20
- El punnto en el arreglo indicará el fin de la palabra
- Se ingresará, de manera dinámica, 4 palabras

## Consignas específicas

- Utilizar substitución al código ASCII
- Desordenar las vocales y luego convertiralas al código ASCII

## Requisitos

- Usar subprogramas
- Usar distintas estructuras
- Validar TODOS los mecanismos
- SOLO utilizar funciones "strlen / .length()" o "substr"

### Investigación

- Función static_cast<int> para convertir caracteres a ASCII
- cómo usar static_cast con un for y arreglos
- ver cómo detenemos la carga de la palabra con el punto. (Do While)
- Ver lógica de las vocales
